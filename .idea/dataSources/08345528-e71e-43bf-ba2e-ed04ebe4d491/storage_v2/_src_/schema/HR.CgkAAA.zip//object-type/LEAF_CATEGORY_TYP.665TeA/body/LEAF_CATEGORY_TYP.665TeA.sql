create TYPE BODY LEAF_CATEGORY_TYP 
    AS 
    MEMBER FUNCTION CATEGORY_DESCRIBE 
    RETURN VARCHAR 
    AS 
    BEGIN
       RETURN  'leaf_category_typ';
    END;

    END 
;
/


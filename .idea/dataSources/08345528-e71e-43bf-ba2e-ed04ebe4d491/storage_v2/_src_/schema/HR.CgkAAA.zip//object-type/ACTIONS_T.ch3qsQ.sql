create TYPE ACTIONS_T 
    AS OBJECT 
    ( 
        SYS_XDBPD$ XDB$RAW_LIST_T , 
        ACTION ACTION_V 
    ) NOT FINAL 
;
/

